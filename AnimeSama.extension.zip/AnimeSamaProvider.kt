package com.cloudstream.plugins

import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*

class AnimeSamaProvider : MainAPI() {

    override var mainUrl = "https://anime-sama.si"
    override var name = "AnimeSama"
    override var lang = "fr"
    override val supportedTypes = setOf(TvType.Anime)

    // 🔍 Recherche d'anime
    override suspend fun search(query: String): List<SearchResponse> {
        val doc = app.get("$mainUrl/search?query=${query.replace(" ", "+")}").document

        return doc.select(".card, .anime-card").mapNotNull {
            val link = it.selectFirst("a") ?: return@mapNotNull null
            val title = it.selectFirst("h3, .card-title")?.text() ?: return@mapNotNull null
            val poster = it.selectFirst("img")?.absUrl("src")

            newAnimeSearchResponse(
                title,
                fixUrl(link.attr("href")),
                TvType.Anime
            ) {
                this.posterUrl = poster
            }
        }
    }

    // 📄 Page anime + épisodes
    override suspend fun load(url: String): LoadResponse {
        val doc = app.get(url).document

        val title = doc.selectFirst("h1")?.text() ?: "Anime"
        val poster = doc.selectFirst("img")?.absUrl("src")
        val description = doc.selectFirst(".description, .synopsis")?.text()

        val episodes = doc.select("a[href*='episode']").mapIndexed { index, el ->
            Episode(
                data = fixUrl(el.attr("href")),
                name = el.text().ifBlank { "Épisode ${index + 1}" },
                episode = index + 1
            )
        }

        return newAnimeLoadResponse(title, url, TvType.Anime) {
            this.posterUrl = poster
            this.plot = description
            this.episodes = episodes
        }
    }

    // ▶️ Liens vidéo (VF / VOSTFR / multi lecteurs)
    override suspend fun loadLinks(
        data: String,
        isCasting: Boolean,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {

        val doc = app.get(data).document
        val iframes = doc.select("iframe[src]")

        iframes.forEach { iframe ->
            val src = iframe.absUrl("src")

            val langTag = when {
                src.contains("vostfr", true) -> "VOSTFR"
                src.contains("vf", true) -> "VF"
                else -> "FR"
            }

            loadExtractor(
                src,
                referer = mainUrl,
                subtitleCallback,
                callback
            )
        }
        return true
    }
}